# store

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```
### More installing details
See [Vue CLI installation](https://www.vuemastery.com/courses/real-world-vue-js/vue-cli/).

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
