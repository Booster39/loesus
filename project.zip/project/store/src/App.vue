<template>
  <b-container fluid="x">
    <div id="app">
      <div>
        <b-navbar toggleable="lg" type="dark" variant="dark">
          <b-navbar-brand href="#">
            <img
              src="./assets/DressCode-Logo.png"
              alt="Dress Code Logo"
              id="dress"
            />
          </b-navbar-brand>

          <div>
            <b-button-group>
              <b-button variant="dark">
                <b-icon icon="person-fill" alt="Account"></b-icon>Account
              </b-button>
              <b-button variant="dark">
                <b-icon icon="inbox-fill" alt="Your Cart"></b-icon> Your Cart
              </b-button>
            </b-button-group>
          </div>

          <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

          <b-collapse id="nav-collapse" is-nav>
            <!-- Right aligned nav items -->
            <b-navbar-nav class="ml-auto">
              <b-nav-form id="search" class="float-right">
                <b-form-input size="sm" class="mr-sm-2" placeholder="Search">
                  <b-button size="sm" class="my-2 my-sm-0" type="submit"
                    >Search</b-button
                  >
                </b-form-input>
              </b-nav-form>

              <b-nav-item-dropdown text="Lang" right>
                <b-dropdown-item href="#">EN</b-dropdown-item>
                <b-dropdown-item href="#">ES</b-dropdown-item>
                <b-dropdown-item href="#">RU</b-dropdown-item>
                <b-dropdown-item href="#">FA</b-dropdown-item>
              </b-nav-item-dropdown>
            </b-navbar-nav>
          </b-collapse>
        </b-navbar>
      </div>

      <b-container>
        <img alt="Vue logo" src="./assets/Dress-Code(1).png" id ="myfont" class="img-fluid"/>
      </b-container>
      <Components msg="Welcome to Your Vue.js App" />

      <div class="page">
        <div id="articles">


          <div id="item">
            <div id="image"></div>
            <div id="description"></div>
            <div id="title"></div>
            <div id="price"></div>
            <div id="rate"></div>
            <div count="count"></div>
          </div>
        </div>
      </div>
      <footer>
        <div class="footer">
            <div style="min-height:610px;">
            </div>

            <div>
              <div class="fluid-container footer">
                <ul id ="contact">
                  <h4>Links</h4>
                  <h4>Social Media</h4>
                  <h4>Questions</h4>
                  <h4>Contact</h4>
                </ul>
              </div>
            </div>
        </div>
      </footer>
    </div>
  </b-container>
</template>

<script>
import Components from "./components/Components.vue";

export default {
  name: "App",
  components: {
    Components,
  },
};
</script>

<style>
#app {
  font-family: Helvetica, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  background-color: white;
  margin-top: 0px;
}

#myfont {
  max-width: 100%;
  height: auto;
  margin: 0;
  margin-right: 0;
  margin-left: 0;
}

b-container {
  padding: auto;
  margin: 0;
  max-width: 50px;
}

b-navbar {
  background: black;
}

#search {
  float: right;
}

.head-page {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 5px 10px;
}

.head-page button {
  height: 40px;
  width: 40px;
  float: left;
  color: black;
  text-align: start;
  text-decoration: none;
  font-size: 10px;
  line-height: 20px;
  border-radius: 4px;
}


header button:hover {
  background-color: #ddd;
  color: black;
}

header button.active {
  background-color: dodgerblue;
  color: white;
}

#button-cart,
#button-account {
  float: right;
}

#dress {
  border-radius: 5px;
  max-width: 50px;
  float: left;
}

@media screen and (max-width: 500px) {
  header button {
    float: none;
    display: block;
    text-align: left;
  }
}

#contact {
  text-align-last: auto;
}

.fluid-container.footer{
  background: rgb(27, 27, 27);
}
.fluid-container.footer > *:last-child {
    margin-bottom: 0px;
    height: 250px;
    color: #fff;
}



</style>
