<template>
  <div class="components">




<b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-1 variant="dark">Electronics</b-button>
      </b-card-header>
      <b-collapse id="accordion-1" visible accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <h3>Electronics</h3>
          <div id="1" >
            <b-card
              title= "WD 2TB Elements Portable…l Hard Drive - USB 3.0 "
              img-src= "https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                USB 3.0 and USB 2.0 Comp…on and operating system
              </b-card-text>

              <b-button href="#" variant="dark">$64</b-button>
            </b-card>
          </div>
          <div id="2">
            <b-card
              title= "SanDisk SSD PLUS 1TB Int…l SSD - SATA III 6 Gb/s"
              img-src= "https://fakestoreapi.com/img/61U7T1koQqL._AC_SX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Easy upgrade for faster …e, OS and application.)
              </b-card-text>

              <b-button href="#" variant="dark">$109</b-button>
            </b-card>
          </div><div id="3">
            <b-card
              title="Silicon Power 256GB SSD …ance Boost SATA III 2.5"
              img-src="https://fakestoreapi.com/img/71kWymZ+c+L._AC_SX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                	3D NAND flash are applie…d enhanced reliability.
              </b-card-text>

              <b-button href="#" variant="dark">$109</b-button>
            </b-card>
          </div>
          <div id="4">
            <b-card
              title=	"WD 4TB Gaming Drive Work…ble External Hard Drive"
              img-src=	"https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Expand your PS4 gaming e…urer's limited warranty
              </b-card-text>

              <b-button href="#" variant="dark">$114</b-button>
            </b-card>
          </div>
          <div id="5">
            <b-card
              title="Acer SB220Q bi 21.5 inch… x 1080) IPS Ultra-Thin"
              img-src=	"https://fakestoreapi.com/img/81QpkIctqPL._AC_SX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                21. 5 inches Full HD (19…gle-178 degree 75 hertz
              </b-card-text>

              <b-button href="#" variant="dark">$599</b-button>
            </b-card>
          </div>



        </b-card-body>
      </b-collapse>
    </b-card>





<b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-2 variant="dark">Men Clothing</b-button>
      </b-card-header>
      <b-collapse id="accordion-2" visible accordion="my-accordion" role="tabpanel">
        <b-card-body>
          
           <h3>Men's Clothing</h3>
    <div id="6">
            <b-card
              title="Fjallraven - Foldsack No. 1 Backpack, Fits 15 Laptops"
              img-src="https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Your perfect pack for everyday use and walks in the forest. Stash your laptop (up to 15 inches) in the padded sleeve, your everyday
              </b-card-text>

              <b-button href="#" variant="dark">$109.95</b-button>
            </b-card>
          </div>
          <div id="7">
            <b-card
              title=	"Mens Casual Premium Slim Fit T-Shirts "
              img-src=	"https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Slim-fitting style, contrast raglan long sleeve, three-button henley placket, light weight & soft fabric for breathable and comfortable wearing. And Solid stitched shirts with round neck made for durability and a great fit for casual fashion wear and diehard baseball fans. The Henley style round neckline includes a three-button placket.
              </b-card-text>

              <b-button href="#" variant="dark">$22.3</b-button>
            </b-card>
          </div>
          <div id="8">
            <b-card
              title="Mens Cotton Jacket"
              img-src="https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                great outerwear jackets for Spring/Autumn/Winter, suitable for many occasions, such as working, hiking, camping, mountain/rock climbing, cycling, traveling or other outdoors. Good gift choice for you or your family member. A warm hearted love to Father, husband or son in this thanksgiving or Christmas Day.
              </b-card-text>

              <b-button href="#" variant="dark">$55.99</b-button>
            </b-card>
          </div>
          <div id="9">
            <b-card
              title="Mens Casual Slim Fit"
              img-src="https://fakestoreapi.com/img/71YXzeOuslL._AC_UY879_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                The color could be slightly different between on the screen and in practice. / Please note that body builds vary by person, therefore, detailed size information should be reviewed below on the product description.
              </b-card-text>

              <b-button href="#" variant="dark">$15.99</b-button>
            </b-card>
          </div>

          
        </b-card-body>
      </b-collapse>
    </b-card>
    
          

   

<b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-3 variant="dark">Women Clothing</b-button>
      </b-card-header>
      <b-collapse id="accordion-3" visible accordion="my-accordion" role="tabpanel">
        <b-card-body>


    <h3>Women's Clothing</h3>
    <div id="10">
            <b-card
              title="BIYLACLESEN Women's 3-in-1 Snowboard Jacket Winter Coats"
              img-src="https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Note:The Jackets is US standard size, Please choose size as your usual wear Material: 100% Polyester; Detachable Liner Fabric: Warm Fleece. Detachable Functional Liner: Skin Friendly, Lightweigt and Warm.Stand Collar Liner jacket, keep you warm in cold weather. Zippered Pockets: 2 Zippered Hand Pockets, 2 Zippered Pockets on Chest (enough to keep cards or keys)and 1 Hidden Pocket Inside.Zippered Hand Pockets and Hidden Pocket keep your things secure. Humanized Design: Adjustable and Detachable Hood and Adjustable cuff to prevent the wind and water,for a comfortable fit. 3 in 1 Detachable Design provide more convenience, you can separate the coat and inner as needed, or wear it together. It is suitable for different season and help you adapt to different climates
              </b-card-text>

              <b-button href="#" variant="dark">$56.99</b-button>
            </b-card>
          </div>
          <div id="11">
            <b-card
              title="Lock and Love Women's Removable Hooded Faux Leather Moto Biker Jacket"
              img-src="https://fakestoreapi.com/img/81XH0e8fefL._AC_UY879_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                100% POLYURETHANE(shell) 100% POLYESTER(lining) 75% POLYESTER 25% COTTON (SWEATER), Faux leather material for style and comfort / 2 pockets of front, 2-For-One Hooded denim style faux leather jacket, Button detail on waist / Detail stitching at sides, HAND WASH ONLY / DO NOT BLEACH / LINE DRY / DO NOT IRON
              </b-card-text>

              <b-button href="#" variant="dark">$29.95</b-button>
            </b-card>
          </div>
          <div id="12">
            <b-card
              title="Rain Jacket Women Windbreaker Striped Climbing Raincoats"
              img-src="https://fakestoreapi.com/img/71HblAHs5xL._AC_UY879_-2.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Lightweight perfet for trip or casual wear---Long sleeve with hooded, adjustable drawstring waist design. Button and zipper front closure raincoat, fully stripes Lined and The Raincoat has 2 side pockets are a good size to hold all kinds of things, it covers the hips, and the hood is generous but doesn't overdo it.Attached Cotton Lined Hood with Adjustable Drawstrings give it a real styled look.
              </b-card-text>

              <b-button href="#" variant="dark">$39.99</b-button>
            </b-card>
          </div>
          <div id="13">
            <b-card
              title="MBJ Women's Solid Short Sleeve Boat Neck V "
              img-src=	"https://fakestoreapi.com/img/71z3kpMAYsL._AC_UY879_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                95% RAYON 5% SPANDEX, Made in USA or Imported, Do Not Bleach, Lightweight fabric with great stretch for comfort, Ribbed on sleeves and neckline / Double stitching on bottom hem
              </b-card-text>

              <b-button href="#" variant="dark">$9.85</b-button>
            </b-card>
          </div>
          <div id="14">
            <b-card
              title=	"Opna Women's Short Sleeve Moisture"
              img-src="https://fakestoreapi.com/img/51eg55uWmdL._AC_UX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                100% Polyester, Machine wash, 100% cationic polyester interlock, Machine Wash & Pre Shrunk for a Great Fit, Lightweight, roomy and highly breathable with moisture wicking fabric which helps to keep moisture away, Soft Lightweight Fabric with comfortable V-neck collar and a slimmer fit, delivers a sleek, more feminine silhouette and Added Comfort
              </b-card-text>

              <b-button href="#" variant="dark">$7.95</b-button>
            </b-card>
          </div>
          <div id="15">
            <b-card
              title="DANVOUY Womens T Shirt Casual Cotton Short"
              img-src=	"https://fakestoreapi.com/img/61pHAEJ4NML._AC_UX679_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                95%Cotton,5%Spandex, Features: Casual, Short Sleeve, Letter Print,V-Neck,Fashion Tees, The fabric is soft and has some stretch., Occasion: Casual/Office/Beach/School/Home/Street. Season: Spring,Summer,Autumn,Winter.
              </b-card-text>

              <b-button href="#" variant="dark">$12.99</b-button>
            </b-card>
          </div>
          
</b-card-body>
      </b-collapse>
    </b-card>



<b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-4 variant="dark">Jewelery</b-button>
      </b-card-header>
      <b-collapse id="accordion-4" visible accordion="my-accordion" role="tabpanel">
        <b-card-body>

    <h3>Jewelery</h3>
    <div id="16">
            <b-card
              title=	"John Hardy Women's Legends Naga Gold & Silver Dragon Station Chain Bracelet"
              img-src=	"https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                From our Legends Collection, the Naga was inspired by the mythical water dragon that protects the ocean's pearl. Wear facing inward to be bestowed with love and abundance, or outward for protection.
              </b-card-text>

              <b-button href="#" variant="dark">$695</b-button>
            </b-card>
          </div>
          <div id="17">
            <b-card
              title=	"Solid Gold Petite Micropave "
              img-src="https://fakestoreapi.com/img/61sbMiUnoGL._AC_UL640_QL65_ML3_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Satisfaction Guaranteed. Return or exchange any order within 30 days.Designed and sold by Hafeez Center in the United States. Satisfaction Guaranteed. Return or exchange any order within 30 days.
              </b-card-text>

              <b-button href="#" variant="dark">$168</b-button>
            </b-card>
          </div>
          <div id="18">
            <b-card
              title=	"White Gold Plated Princess"
              img-src="https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                Classic Created Wedding Engagement Solitaire Diamond Promise Ring for Her. Gifts to spoil your love more for Engagement, Wedding, Anniversary, Valentine's Day...
              </b-card-text>

              <b-button href="#" variant="dark">$9.99</b-button>
            </b-card>
          </div>
          <div id="19">
            <b-card
              title=	"Pierced Owl Rose Gold Plated Stainless Steel Double"
              img-src="https://fakestoreapi.com/img/51UDEzMJVpL._AC_UL640_QL65_ML3_.jpg"
              img-alt="Image"
              img-top
              tag="article"
              style="max-width: 20rem"
              class="mb-2"
            >
              <b-card-text>
                "Rose Gold Plated Double Flared Tunnel Plug Earrings. Made of 316L Stainless Steel"
              </b-card-text>

              <b-button href="#" variant="dark">$10.99</b-button>
            </b-card>
          </div>

          </b-card-body>
      </b-collapse>
    </b-card>

  </div>
</template>

<script>
export default {
  name: "Components",
  props: {
    msg: String,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
* {
  font-family: Georgia, 'Times New Roman', Times, serif;
}

h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: rgb(194, 194, 204);
}
</style>
